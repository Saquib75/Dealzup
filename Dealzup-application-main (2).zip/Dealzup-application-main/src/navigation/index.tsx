import { StyleSheet, Text, View } from 'react-native'
import React from 'react'
import {NavigationContainer} from '@react-navigation/native'
import MainNavigation from './main.navigation'
const Navigation:React.FC<any> = () => {
  return (
    <React.Fragment>
      <NavigationContainer>
        <MainNavigation />
      </NavigationContainer>
    </React.Fragment>
  )
}

export default Navigation

const styles = StyleSheet.create({})