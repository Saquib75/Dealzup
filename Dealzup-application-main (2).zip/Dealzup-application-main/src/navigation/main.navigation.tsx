import { StyleSheet, View } from 'react-native'
import React from 'react'
import Text from '../components/ui/text/text.ui'

const MainNavigation = () => {
  return (
    <View>
      <Text>MainNavigation</Text>
    </View>
  )
}

export default MainNavigation

const styles = StyleSheet.create({})