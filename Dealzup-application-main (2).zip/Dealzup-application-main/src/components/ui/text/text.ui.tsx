import { StyleSheet, Text as NativeText,TextProps as NativeTextProps, View } from 'react-native'
import React from 'react'

export interface TextProps extends NativeTextProps{

}

const Text:React.FC<TextProps> = ({children,...rest}) => {
  return (
    <NativeText {...rest}>
        {children}
    </NativeText>
  )
}

export default Text

const styles = StyleSheet.create({})